import "./Hero.css";

export default function Hero() {
  return (
    <section className="dpf-hero">

      {/* =========================================
          DEEP SPACE ENVIRONMENT
      ========================================= */}
      <div className="dpf-hero__space" aria-hidden="true">
        <div className="dpf-hero__stars" />
        <div className="dpf-hero__nebula dpf-hero__nebula--blue" />
        <div className="dpf-hero__nebula dpf-hero__nebula--gold" />
      </div>


      {/* =========================================
    HERO CONTENT
========================================= */}
<div className="dpf-hero__content">

  <h1 className="dpf-hero__title">

    <span>DPF OS</span>

    <span className="dpf-hero__subtitle">
      Dynamic Positional Football
    </span>

    <span>
      A complete operating system
    </span>

    <span className="dpf-hero__title-accent">
      for football.
    </span>

  </h1>


  <p className="dpf-hero__description">
    A unified football system integrating philosophy,
    methodology, coaching, performance, research,
    analytics, and education.
  </p>


  <div className="dpf-hero__actions">

    <a
      href="/platform"
      className="dpf-hero__button dpf-hero__button--primary"
    >
      Explore Platform
      <span>→</span>
    </a>

    <a
      href="/library"
      className="dpf-hero__button dpf-hero__button--secondary"
    >
      DPF Library
    </a>

  </div>


  <div className="dpf-hero__stats">

    <div className="dpf-hero__stat">
      <strong>10+</strong>
      <span>KNOWLEDGE</span>
      <small>VOLUMES</small>
    </div>

    <div className="dpf-hero__stat">
      <strong>100+</strong>
      <span>FRAMEWORKS &</span>
      <small>CONCEPTS</small>
    </div>

    <div className="dpf-hero__stat">
      <strong>∞</strong>
      <span>SYSTEM</span>
      <small>EVOLUTION</small>
    </div>

  </div>

</div>

      {/* =========================================
          CORE ENGINE
      ========================================= */}
      <div className="dpf-hero__core">

        <div className="dpf-hero__orbital dpf-hero__orbital--one">
        <div className="dpf-hero__planet dpf-hero__planet--1" />
        <div className="dpf-hero__planet dpf-hero__planet--2" />
      </div>

        <div className="dpf-hero__orbital dpf-hero__orbital--two">
        <div className="dpf-hero__planet dpf-hero__planet--3" />
        <div className="dpf-hero__planet dpf-hero__planet--4" />
       </div>

       <div className="dpf-hero__orbital dpf-hero__orbital--three">
       <div className="dpf-hero__planet dpf-hero__planet--5" />
       <div className="dpf-hero__planet dpf-hero__planet--6" />
       </div>
       
        {/* =========================================
           PLANETARY ORBIT SYSTEM
      ========================================= */}

       <div className="dpf-hero__planet-orbit dpf-hero__planet-orbit--one">
       <div className="dpf-hero__planet dpf-hero__planet--a" />
       <div className="dpf-hero__planet dpf-hero__planet--b" />
       </div>

       <div className="dpf-hero__planet-orbit dpf-hero__planet-orbit--two">
       <div className="dpf-hero__planet dpf-hero__planet--c" />
       <div className="dpf-hero__planet dpf-hero__planet--d" />
       </div>

       <div className="dpf-hero__planet-orbit dpf-hero__planet-orbit--three">
       <div className="dpf-hero__planet dpf-hero__planet--e" />
       <div className="dpf-hero__planet dpf-hero__planet--f" />
       </div>
        
      {/* =========================================
           ORBITAL CONNECTIONS
       ========================================= */}

       <div className="dpf-hero__connection dpf-hero__connection--one" />
       <div className="dpf-hero__connection dpf-hero__connection--two" />
       <div className="dpf-hero__connection dpf-hero__connection--three" />
        
        {/* Orbital Connections */}

       <div className="dpf-hero__connection dpf-hero__connection--one" />
       <div className="dpf-hero__connection dpf-hero__connection--two" />
       <div className="dpf-hero__connection dpf-hero__connection--three" />

        <div className="dpf-hero__core-sphere">

          <div className="dpf-hero__core-glow" />

          <div className="dpf-hero__core-label">
            <strong>DPF OS</strong>
            <span>CORE ENGINE</span>
          </div>

        </div>


        {/* =====================================
            ECOSYSTEM NODES
        ===================================== */}

        <div className="dpf-hero__node dpf-hero__node--clubs">
          <strong>CLUBS</strong>
          <span>Worldwide Network</span>
        </div>


        <div className="dpf-hero__node dpf-hero__node--academies">
          <strong>ACADEMIES</strong>
          <span>Development System</span>
        </div>


        <div className="dpf-hero__node dpf-hero__node--players">
          <strong>PLAYERS</strong>
          <span>At the Center</span>
        </div>


        <div className="dpf-hero__node dpf-hero__node--federations">
          <strong>FEDERATIONS</strong>
          <span>Strategic Partners</span>
        </div>

      </div>


      {/* =========================================================
    DPF PITCH DATA ENVIRONMENT
    REAL FOOTBALL PITCH + DPF 18 FUNCTIONAL ZONES
========================================================= */}

<div className="dpf-hero__pitch">

  <div className="dpf-hero__pitch-surface">

    {/* =====================================================
        REAL FOOTBALL PITCH
    ===================================================== */}

    <svg
      className="dpf-hero__pitch-svg"
      viewBox="0 0 1000 400"
      preserveAspectRatio="none"
      aria-hidden="true"
    >

      {/* ===================================================
          SUBTLE PITCH SURFACE
      =================================================== */}

      <rect
        className="dpf-pitch-surface-fill"
        x="100"
        y="60"
        width="800"
        height="280"
      />


      {/* ===================================================
          FINE DATA GRID
      =================================================== */}

      <g className="dpf-pitch-fine-grid">

        {/* Vertical fine grid */}

        {Array.from({ length: 21 }).map((_, index) => (
          <line
            key={`fine-v-${index}`}
            x1={100 + index * 40}
            y1="60"
            x2={100 + index * 40}
            y2="340"
          />
        ))}


        {/* Horizontal fine grid */}

        {Array.from({ length: 15 }).map((_, index) => (
          <line
            key={`fine-h-${index}`}
            x1="100"
            y1={60 + index * 20}
            x2="900"
            y2={60 + index * 20}
          />
        ))}

      </g>


      {/* ===================================================
          DPF 18 LONGITUDINAL FUNCTIONAL ZONES
          
          18 zones
          17 internal boundaries
      =================================================== */}

      <g className="dpf-pitch-zones">

        {Array.from({ length: 17 }).map((_, index) => {

          const x =
            100 +
            ((index + 1) * 800) / 18;

          return (
            <line
              key={`dpf-zone-${index + 1}`}
              x1={x}
              y1="60"
              x2={x}
              y2="340"
            />
          );

        })}

      </g>


      {/* ===================================================
          OUTER PITCH BOUNDARY
      =================================================== */}

      <rect
        className="dpf-pitch-line"
        x="100"
        y="60"
        width="800"
        height="280"
      />


      {/* ===================================================
          CENTER LINE
      =================================================== */}

      <line
        className="dpf-pitch-line"
        x1="500"
        y1="60"
        x2="500"
        y2="340"
      />


      {/* ===================================================
          CENTER CIRCLE
      =================================================== */}

      <circle
        className="dpf-pitch-line"
        cx="500"
        cy="200"
        r="48"
      />


      {/* Center point */}

      <circle
        className="dpf-pitch-center-point"
        cx="500"
        cy="200"
        r="4"
      />


      {/* ===================================================
          LEFT PENALTY AREA
      =================================================== */}

      <rect
        className="dpf-pitch-line"
        x="100"
        y="125"
        width="120"
        height="150"
      />


      {/* Left 6-yard box */}

      <rect
        className="dpf-pitch-line"
        x="100"
        y="165"
        width="55"
        height="70"
      />


      {/* Left penalty spot */}

      <circle
        className="dpf-pitch-dot"
        cx="180"
        cy="200"
        r="3"
      />


      {/* Left penalty arc */}

      <path
        className="dpf-pitch-line"
        d="M 220 158 A 48 48 0 0 0 220 242"
      />


      {/* ===================================================
          RIGHT PENALTY AREA
      =================================================== */}

      <rect
        className="dpf-pitch-line"
        x="780"
        y="125"
        width="120"
        height="150"
      />


      {/* Right 6-yard box */}

      <rect
        className="dpf-pitch-line"
        x="845"
        y="165"
        width="55"
        height="70"
      />


      {/* Right penalty spot */}

      <circle
        className="dpf-pitch-dot"
        cx="820"
        cy="200"
        r="3"
      />


      {/* Right penalty arc */}

      <path
        className="dpf-pitch-line"
        d="M 780 158 A 48 48 0 0 1 780 242"
      />


      {/* ===================================================
          LEFT GOAL
      =================================================== */}

      <rect
        className="dpf-pitch-goal"
        x="72"
        y="170"
        width="28"
        height="60"
      />


      {/* Left goal net */}

      <line
        className="dpf-pitch-goal-net"
        x1="72"
        y1="185"
        x2="100"
        y2="185"
      />

      <line
        className="dpf-pitch-goal-net"
        x1="72"
        y1="200"
        x2="100"
        y2="200"
      />

      <line
        className="dpf-pitch-goal-net"
        x1="72"
        y1="215"
        x2="100"
        y2="215"
      />


      {/* ===================================================
          RIGHT GOAL
      =================================================== */}

      <rect
        className="dpf-pitch-goal"
        x="900"
        y="170"
        width="28"
        height="60"
      />


      {/* Right goal net */}

      <line
        className="dpf-pitch-goal-net"
        x1="900"
        y1="185"
        x2="928"
        y2="185"
      />

      <line
        className="dpf-pitch-goal-net"
        x1="900"
        y1="200"
        x2="928"
        y2="200"
      />

      <line
        className="dpf-pitch-goal-net"
        x1="900"
        y1="215"
        x2="928"
        y2="215"
      />

    </svg>


    {/* =====================================================
        DATA / PLAYER POINTS
    ===================================================== */}

    <div className="dpf-hero__player p1" />
    <div className="dpf-hero__player p2" />
    <div className="dpf-hero__player p3" />
    <div className="dpf-hero__player p4" />
    <div className="dpf-hero__player p5" />

    <div className="dpf-hero__player p6" />

    <div className="dpf-hero__player p7" />
    <div className="dpf-hero__player p8" />
    <div className="dpf-hero__player p9" />
    <div className="dpf-hero__player p10" />
    <div className="dpf-hero__player p11" />

  </div>

</div>

      {/* =========================================
          HERO SYSTEM LAYERS
      ========================================= */}

      <div className="dpf-hero__layer dpf-hero__layer--pitch">
        PITCH DATA ENVIRONMENT
      </div>


      <div className="dpf-hero__layer dpf-hero__layer--data">
        DATA & ANALYTICS
      </div>


      <div className="dpf-hero__layer dpf-hero__layer--infra">
        INFRASTRUCTURE
      </div>


      {/* =========================================
          SYSTEM MODULES
      ========================================= */}
      <div className="dpf-hero__modules">

        <div className="dpf-hero__module dpf-hero__module--gold">
          <span>01</span>
          <div>
            <strong>GAME</strong>
            <small>Game Model · Principles · Logic</small>
          </div>
        </div>


        <div className="dpf-hero__module dpf-hero__module--gold">
          <span>02</span>
          <div>
            <strong>TACTICAL</strong>
            <small>Structures · Behaviors · Playbook</small>
          </div>
        </div>


        <div className="dpf-hero__module dpf-hero__module--gold">
          <span>03</span>
          <div>
            <strong>PLAYER</strong>
            <small>Roles · Development · Profiles</small>
          </div>
        </div>


        <div className="dpf-hero__module dpf-hero__module--gold">
          <span>04</span>
          <div>
            <strong>COACHING</strong>
            <small>Training · Methodology · Practice</small>
          </div>
        </div>


        <div className="dpf-hero__module">
          <span>05</span>
          <div>
            <strong>PERFORMANCE</strong>
            <small>Monitoring · KPIs · Decision Support</small>
          </div>
        </div>


        <div className="dpf-hero__module">
          <span>06</span>
          <div>
            <strong>INTELLIGENCE</strong>
            <small>Analytics · Research · Insights</small>
          </div>
        </div>


        <div className="dpf-hero__module">
          <span>07</span>
          <div>
            <strong>KNOWLEDGE</strong>
            <small>Library · Principles · Frameworks</small>
          </div>
        </div>


        <div className="dpf-hero__module">
          <span>08</span>
          <div>
            <strong>TECHNOLOGY</strong>
            <small>Platform · Infrastructure · Security</small>
          </div>
        </div>

      </div>


      {/* =========================================
          SYSTEM STATUS
      ========================================= */}
      <div className="dpf-hero__status">

        <span />

        <strong>SYSTEM ONLINE</strong>

        <small>
          ALL MODULES SYNCHRONIZED
        </small>

      </div>

    </section>
  );
}