import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        © DPF Operating System
      </div>
    </footer>
  );
}
